﻿namespace Psalario
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalarioBruto = new System.Windows.Forms.Label();
            this.lblNumFilhos = new System.Windows.Forms.Label();
            this.lblINSS = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblSalFamilia = new System.Windows.Forms.Label();
            this.lblSalLiquido = new System.Windows.Forms.Label();
            this.lblDescINSS = new System.Windows.Forms.Label();
            this.lblDescIRPF = new System.Windows.Forms.Label();
            this.btnVerifDesc = new System.Windows.Forms.Button();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.mskbxSalBruto = new System.Windows.Forms.MaskedTextBox();
            this.nupFilhos = new System.Windows.Forms.NumericUpDown();
            this.txtAliqINSS = new System.Windows.Forms.TextBox();
            this.txtAliqIRPF = new System.Windows.Forms.TextBox();
            this.txtSalFamilia = new System.Windows.Forms.TextBox();
            this.txtSalLiquido = new System.Windows.Forms.TextBox();
            this.mskbxDescINSS = new System.Windows.Forms.MaskedTextBox();
            this.mskbxDescIRPF = new System.Windows.Forms.MaskedTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.nupFilhos)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.lblNome.Location = new System.Drawing.Point(44, 37);
            this.lblNome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(186, 25);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome funcionário:";
            // 
            // lblSalarioBruto
            // 
            this.lblSalarioBruto.AutoSize = true;
            this.lblSalarioBruto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.lblSalarioBruto.Location = new System.Drawing.Point(44, 97);
            this.lblSalarioBruto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalarioBruto.Name = "lblSalarioBruto";
            this.lblSalarioBruto.Size = new System.Drawing.Size(140, 25);
            this.lblSalarioBruto.TabIndex = 1;
            this.lblSalarioBruto.Text = "Salário bruto:";
            // 
            // lblNumFilhos
            // 
            this.lblNumFilhos.AutoSize = true;
            this.lblNumFilhos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.lblNumFilhos.Location = new System.Drawing.Point(44, 155);
            this.lblNumFilhos.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNumFilhos.Name = "lblNumFilhos";
            this.lblNumFilhos.Size = new System.Drawing.Size(180, 25);
            this.lblNumFilhos.TabIndex = 2;
            this.lblNumFilhos.Text = "Número de filhos:";
            // 
            // lblINSS
            // 
            this.lblINSS.AutoSize = true;
            this.lblINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.lblINSS.Location = new System.Drawing.Point(43, 367);
            this.lblINSS.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblINSS.Name = "lblINSS";
            this.lblINSS.Size = new System.Drawing.Size(150, 25);
            this.lblINSS.TabIndex = 3;
            this.lblINSS.Text = "Alíquota INSS:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.label1.Location = new System.Drawing.Point(44, 421);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(149, 25);
            this.label1.TabIndex = 4;
            this.label1.Text = "Alíquota IRPF:";
            // 
            // lblSalFamilia
            // 
            this.lblSalFamilia.AutoSize = true;
            this.lblSalFamilia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.lblSalFamilia.Location = new System.Drawing.Point(44, 478);
            this.lblSalFamilia.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalFamilia.Name = "lblSalFamilia";
            this.lblSalFamilia.Size = new System.Drawing.Size(160, 25);
            this.lblSalFamilia.TabIndex = 5;
            this.lblSalFamilia.Text = "Salário Família:";
            // 
            // lblSalLiquido
            // 
            this.lblSalLiquido.AutoSize = true;
            this.lblSalLiquido.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.lblSalLiquido.Location = new System.Drawing.Point(44, 530);
            this.lblSalLiquido.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalLiquido.Name = "lblSalLiquido";
            this.lblSalLiquido.Size = new System.Drawing.Size(161, 25);
            this.lblSalLiquido.TabIndex = 6;
            this.lblSalLiquido.Text = "Salário Líquido:";
            // 
            // lblDescINSS
            // 
            this.lblDescINSS.AutoSize = true;
            this.lblDescINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.lblDescINSS.Location = new System.Drawing.Point(585, 367);
            this.lblDescINSS.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDescINSS.Name = "lblDescINSS";
            this.lblDescINSS.Size = new System.Drawing.Size(169, 25);
            this.lblDescINSS.TabIndex = 7;
            this.lblDescINSS.Text = "Desconto INSS: ";
            // 
            // lblDescIRPF
            // 
            this.lblDescIRPF.AutoSize = true;
            this.lblDescIRPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.lblDescIRPF.Location = new System.Drawing.Point(585, 421);
            this.lblDescIRPF.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDescIRPF.Name = "lblDescIRPF";
            this.lblDescIRPF.Size = new System.Drawing.Size(168, 25);
            this.lblDescIRPF.TabIndex = 8;
            this.lblDescIRPF.Text = "Desconto IRPF: ";
            // 
            // btnVerifDesc
            // 
            this.btnVerifDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.btnVerifDesc.Location = new System.Drawing.Point(204, 241);
            this.btnVerifDesc.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnVerifDesc.Name = "btnVerifDesc";
            this.btnVerifDesc.Size = new System.Drawing.Size(313, 48);
            this.btnVerifDesc.TabIndex = 9;
            this.btnVerifDesc.Text = "Verificar Desconto";
            this.btnVerifDesc.UseVisualStyleBackColor = true;
            this.btnVerifDesc.Click += new System.EventHandler(this.btnVerifDesc_Click);
            // 
            // txtNome
            // 
            this.txtNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.txtNome.Location = new System.Drawing.Point(259, 33);
            this.txtNome.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(721, 31);
            this.txtNome.TabIndex = 10;
            this.txtNome.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNome_KeyPress);
            // 
            // mskbxSalBruto
            // 
            this.mskbxSalBruto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.mskbxSalBruto.Location = new System.Drawing.Point(259, 94);
            this.mskbxSalBruto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.mskbxSalBruto.Mask = "00999.00";
            this.mskbxSalBruto.Name = "mskbxSalBruto";
            this.mskbxSalBruto.Size = new System.Drawing.Size(193, 31);
            this.mskbxSalBruto.TabIndex = 11;
            this.mskbxSalBruto.Validated += new System.EventHandler(this.mskbxSalBruto_Validated);
            // 
            // nupFilhos
            // 
            this.nupFilhos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.nupFilhos.Location = new System.Drawing.Point(259, 153);
            this.nupFilhos.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.nupFilhos.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nupFilhos.Name = "nupFilhos";
            this.nupFilhos.Size = new System.Drawing.Size(160, 31);
            this.nupFilhos.TabIndex = 12;
            // 
            // txtAliqINSS
            // 
            this.txtAliqINSS.Enabled = false;
            this.txtAliqINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.txtAliqINSS.Location = new System.Drawing.Point(232, 363);
            this.txtAliqINSS.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtAliqINSS.Name = "txtAliqINSS";
            this.txtAliqINSS.Size = new System.Drawing.Size(297, 31);
            this.txtAliqINSS.TabIndex = 13;
            // 
            // txtAliqIRPF
            // 
            this.txtAliqIRPF.Enabled = false;
            this.txtAliqIRPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.txtAliqIRPF.Location = new System.Drawing.Point(232, 417);
            this.txtAliqIRPF.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtAliqIRPF.Name = "txtAliqIRPF";
            this.txtAliqIRPF.Size = new System.Drawing.Size(297, 31);
            this.txtAliqIRPF.TabIndex = 14;
            // 
            // txtSalFamilia
            // 
            this.txtSalFamilia.Enabled = false;
            this.txtSalFamilia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.txtSalFamilia.Location = new System.Drawing.Point(232, 474);
            this.txtSalFamilia.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSalFamilia.Name = "txtSalFamilia";
            this.txtSalFamilia.Size = new System.Drawing.Size(297, 31);
            this.txtSalFamilia.TabIndex = 15;
            // 
            // txtSalLiquido
            // 
            this.txtSalLiquido.Enabled = false;
            this.txtSalLiquido.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.txtSalLiquido.Location = new System.Drawing.Point(232, 527);
            this.txtSalLiquido.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSalLiquido.Name = "txtSalLiquido";
            this.txtSalLiquido.Size = new System.Drawing.Size(297, 31);
            this.txtSalLiquido.TabIndex = 16;
            // 
            // mskbxDescINSS
            // 
            this.mskbxDescINSS.Enabled = false;
            this.mskbxDescINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.mskbxDescINSS.Location = new System.Drawing.Point(772, 364);
            this.mskbxDescINSS.Name = "mskbxDescINSS";
            this.mskbxDescINSS.Size = new System.Drawing.Size(297, 32);
            this.mskbxDescINSS.TabIndex = 17;
            // 
            // mskbxDescIRPF
            // 
            this.mskbxDescIRPF.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.IncludePrompt;
            this.mskbxDescIRPF.Enabled = false;
            this.mskbxDescIRPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.mskbxDescIRPF.Location = new System.Drawing.Point(772, 418);
            this.mskbxDescIRPF.Name = "mskbxDescIRPF";
            this.mskbxDescIRPF.Size = new System.Drawing.Size(297, 32);
            this.mskbxDescIRPF.TabIndex = 18;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1196, 720);
            this.Controls.Add(this.mskbxDescIRPF);
            this.Controls.Add(this.mskbxDescINSS);
            this.Controls.Add(this.txtSalLiquido);
            this.Controls.Add(this.txtSalFamilia);
            this.Controls.Add(this.txtAliqIRPF);
            this.Controls.Add(this.txtAliqINSS);
            this.Controls.Add(this.nupFilhos);
            this.Controls.Add(this.mskbxSalBruto);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.btnVerifDesc);
            this.Controls.Add(this.lblDescIRPF);
            this.Controls.Add(this.lblDescINSS);
            this.Controls.Add(this.lblSalLiquido);
            this.Controls.Add(this.lblSalFamilia);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblINSS);
            this.Controls.Add(this.lblNumFilhos);
            this.Controls.Add(this.lblSalarioBruto);
            this.Controls.Add(this.lblNome);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.nupFilhos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalarioBruto;
        private System.Windows.Forms.Label lblNumFilhos;
        private System.Windows.Forms.Label lblINSS;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblSalFamilia;
        private System.Windows.Forms.Label lblSalLiquido;
        private System.Windows.Forms.Label lblDescINSS;
        private System.Windows.Forms.Label lblDescIRPF;
        private System.Windows.Forms.Button btnVerifDesc;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.MaskedTextBox mskbxSalBruto;
        private System.Windows.Forms.NumericUpDown nupFilhos;
        private System.Windows.Forms.TextBox txtAliqINSS;
        private System.Windows.Forms.TextBox txtAliqIRPF;
        private System.Windows.Forms.TextBox txtSalFamilia;
        private System.Windows.Forms.TextBox txtSalLiquido;
        private System.Windows.Forms.MaskedTextBox mskbxDescINSS;
        private System.Windows.Forms.MaskedTextBox mskbxDescIRPF;
    }
}

