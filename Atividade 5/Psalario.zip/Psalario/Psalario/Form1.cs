﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        double SalBruto, DescINSS, DescIRPF, SalFamilia, numFilhos, salLiquido;


        public Form1()
        {
            InitializeComponent();
        }

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            Char[] Numeros = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };

            bool temNumero = Numeros.Contains(e.KeyChar);
            if (temNumero)
            {
                MessageBox.Show("Nome não pode conter números!");
                SendKeys.Send("{BACKSPACE}");
            }
        }

        private void btnVerifDesc_Click(object sender, EventArgs e)
        {
            SalBruto = Convert.ToDouble(mskbxSalBruto.Text);

            //Desconto INSS//
            if (SalBruto <= 800.47)
            {
                txtAliqINSS.Text = "7,65%";
                DescINSS = SalBruto * 0.0765;
                mskbxDescINSS.Text = DescINSS.ToString("N2");
            }
            else if (SalBruto >= 800.48 && SalBruto <= 1050)
            {
                txtAliqINSS.Text = "8,65%";
                DescINSS = SalBruto * 0.0865;
                mskbxDescINSS.Text = DescINSS.ToString("N2");
            }
            else if (SalBruto >= 1050.01 && SalBruto <= 1400.77)
            {
                txtAliqINSS.Text = "9.00%";
                DescINSS = SalBruto * 0.09;
                mskbxDescINSS.Text = DescINSS.ToString("N2");
            }
            else if (SalBruto >= 1400.78 && SalBruto <= 2801.56)
            {
                txtAliqINSS.Text = "11.00%";
                DescINSS = SalBruto * 0.11;
                mskbxDescINSS.Text = DescINSS.ToString("N2");
            }
            else
            {
                txtAliqINSS.Text = "Teto";
                DescINSS = 308.17;
                mskbxDescINSS.Text = "308,17";
            }

            //Desconto IRPF//
            if (SalBruto > 1257.12 && SalBruto <= 2512.08)
            {
                txtAliqIRPF.Text = "15.00%";
                DescIRPF = SalBruto * 0.15;
                mskbxDescIRPF.Text = DescIRPF.ToString("N2");
            }
            else if (SalBruto > 2512.08)
            {
                txtAliqIRPF.Text = "27.50%";
                DescIRPF = SalBruto * 0.275;
                mskbxDescIRPF.Text = DescIRPF.ToString("N2");
            }
            else
            {
                txtAliqIRPF.Text = "Isento";
                mskbxDescIRPF.Text = "0,00";
            }

            //Salario Familia//
            numFilhos = (double)nupFilhos.Value;
            if (SalBruto <= 435.52)
            {
                SalFamilia = 22.33 * numFilhos;
                txtSalFamilia.Text = SalFamilia.ToString("N2");
            }
            else if (SalBruto > 435.52 && SalBruto <= 654.61)
            {
                SalFamilia = 15.74 * numFilhos;
                txtSalFamilia.Text = SalFamilia.ToString("N2");
            }
            else
            {
                SalFamilia = 0.00;
                txtSalFamilia.Text = SalFamilia.ToString("N2");
            }

            //Salario Liquido//
            salLiquido = SalBruto - DescINSS - DescIRPF + SalFamilia;
            txtSalLiquido.Text = salLiquido.ToString("N2");

            txtNome.Focus();
        }


        private void mskbxSalBruto_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxSalBruto.Text, out SalBruto))
            {
                MessageBox.Show("Salário Inválido!");
                mskbxSalBruto.Focus();
            }
        }
    }
}
