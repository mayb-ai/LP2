﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {

        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNum_Click(object sender, EventArgs e)
        {
            int c = 0, num = 0;
            while (c < rchtxtTexto.Text.Length)
            { 
                if (char.IsNumber(rchtxtTexto.Text[c]))
                {
                    num++;
                }
                c++;
            }
            MessageBox.Show($"Quantidade de números é: {num}");
        }

        private void btnPosicao_Click(object sender, EventArgs e)
        {
            int c, branco = 0;
            for (c =0; c < rchtxtTexto.Text.Length; c++) 
            {
                if (char.IsWhiteSpace(rchtxtTexto.Text[c]))
                    branco++;
            }
            MessageBox.Show($"Quantidade de caracteres brancos é: {branco}");
        }

        private void btnCaracter_Click(object sender, EventArgs e)
        {
            int letra = 0;
            foreach (char c in rchtxtTexto.Text)
            {
                if (char.IsLetter(c))
                    letra++;
            }

            MessageBox.Show($"Quantidade de letras é: {letra}");
        }
    }
}
