namespace PImc
{
    public partial class Form1 : Form
    {
        double peso, altura, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxPeso.Text, out peso))
            {
                MessageBox.Show("Peso inv�lido!");
                mskbxPeso.Focus();
            }
        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxAltura.Text, out altura))
            {
                MessageBox.Show("Altura inv�lida!");
                mskbxAltura.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            resultado = peso / Math.Pow(altura, 2);
            resultado = Math.Round(resultado, 2);
            txtImc.Text = resultado.ToString();

            if (resultado < 18.5)
                MessageBox.Show($"IMC: {resultado} \nClassifica��o: Magreza \nObesidade (Grau): 0");
            else if (resultado >= 18.5 && resultado <= 24.9)
                MessageBox.Show($"IMC: {resultado} \nClassifica��o: Normal \nObesidade (Grau): 0");
            else if (resultado >= 25 && resultado <= 29.9)
                MessageBox.Show($"IMC: {resultado} \nClassifica��o: Sobrepeso \nObesidade (Grau): I");
            else if (resultado >= 30 && resultado <= 39.9)
                MessageBox.Show($"IMC: {resultado} \nClassifica��o: Obesidade \nObesidade (Grau): II");
            else
                MessageBox.Show($"IMC: {resultado} \nClassifica��o: Obesidade Grave \nObesidade (Grau): III");
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            txtImc.Clear();
            mskbxAltura.Clear();
            mskbxPeso.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
