namespace PTriangulo
{
    public partial class Form1 : Form
    {
        decimal A, B, C;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            decimal E = Math.Abs(B - C), F = Math.Abs(A - B), G = Math.Abs(A - C);
            if (A <= 0 || B <= 0 || C <= 0)
            {
                MessageBox.Show("Os lados do tri�ngulo devem ter valores maiores que zero.");
            }
            else if ((E < A && A < B + C) && (G < B && A + C > B) && (F < C && A + B > C))
            {
                if (A == B && B == C)
                {
                    MessageBox.Show("� um tri�ngulo equil�tero.");
                }
                else if (A == B || A == C || B == C)
                {
                    MessageBox.Show("� um tri�ngulo is�sceles.");
                }
                else
                {
                    MessageBox.Show("� um tri�ngulo escaleno.");
                }
            }
            else
            {
                MessageBox.Show("Os lados fornecidos n�o formam um tri�ngulo.");
            }
        }

        private void txtLado1_Validated(object sender, EventArgs e)
        {
            if (!decimal.TryParse(txtLado1.Text, out A) && A == 0)
            {
                MessageBox.Show("Lado 1 inv�lido");
                txtLado1.Focus();
            }
        }

        private void txtLado2_Validated(object sender, EventArgs e)
        {
            if (!decimal.TryParse(txtLado2.Text, out B))
            {
                MessageBox.Show("Lado 2 inv�lido");
                txtLado2.Focus();
            }
        }

        private void txtLado3_Validated(object sender, EventArgs e)
        {
            if (!decimal.TryParse(txtLado3.Text, out C))
            {
                MessageBox.Show("Lado 3 inv�lido");
                txtLado3.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLado1.Clear();
            txtLado2.Clear();
            txtLado3.Clear();
            txtLado1.Focus();
        }
    }
}
