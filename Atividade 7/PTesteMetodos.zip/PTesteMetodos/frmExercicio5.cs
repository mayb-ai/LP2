﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PTesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }
        int num1, num2;
        private void btnRandom_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrEmpty(txtNum1.Text) || string.IsNullOrEmpty(txtNum2.Text))
            {
                MessageBox.Show("Números inválidos.");

            }

            if (!int.TryParse(txtNum1.Text, out num1) || !int.TryParse(txtNum2.Text, out num2))
            {
                MessageBox.Show("Por favor, insira números válidos.");
            }

            if (num2 < num1)
            {
                MessageBox.Show("O número 1 deve ser menor que o número 2.");
            }

            Random random = new Random();

            int aleatorio = random.Next(num1, num2 + 1);

            MessageBox.Show($"Número aleatório gerado: {aleatorio}");
        }
    }
}
