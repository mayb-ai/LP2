﻿namespace PTriangulo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblLado1 = new Label();
            lblLado2 = new Label();
            txtLado1 = new TextBox();
            txtLado2 = new TextBox();
            txtLado3 = new TextBox();
            lblLado3 = new Label();
            btnCalcular = new Button();
            btnSair = new Button();
            btnLimpar = new Button();
            SuspendLayout();
            // 
            // lblLado1
            // 
            lblLado1.AutoSize = true;
            lblLado1.Font = new Font("Segoe UI", 14.2F);
            lblLado1.Location = new Point(111, 114);
            lblLado1.Name = "lblLado1";
            lblLado1.Size = new Size(90, 32);
            lblLado1.TabIndex = 0;
            lblLado1.Text = "Lado 1:";
            // 
            // lblLado2
            // 
            lblLado2.AutoSize = true;
            lblLado2.Font = new Font("Segoe UI", 14.2F);
            lblLado2.Location = new Point(111, 175);
            lblLado2.Name = "lblLado2";
            lblLado2.Size = new Size(90, 32);
            lblLado2.TabIndex = 1;
            lblLado2.Text = "Lado 2:";
            // 
            // txtLado1
            // 
            txtLado1.Font = new Font("Segoe UI", 14.2F);
            txtLado1.Location = new Point(224, 111);
            txtLado1.Name = "txtLado1";
            txtLado1.Size = new Size(199, 39);
            txtLado1.TabIndex = 2;
            txtLado1.Validated += txtLado1_Validated;
            // 
            // txtLado2
            // 
            txtLado2.Font = new Font("Segoe UI", 14.2F);
            txtLado2.Location = new Point(224, 172);
            txtLado2.Name = "txtLado2";
            txtLado2.Size = new Size(199, 39);
            txtLado2.TabIndex = 3;
            txtLado2.Validated += txtLado2_Validated;
            // 
            // txtLado3
            // 
            txtLado3.Font = new Font("Segoe UI", 14.2F);
            txtLado3.Location = new Point(224, 230);
            txtLado3.Name = "txtLado3";
            txtLado3.Size = new Size(199, 39);
            txtLado3.TabIndex = 5;
            txtLado3.Validated += txtLado3_Validated;
            // 
            // lblLado3
            // 
            lblLado3.AutoSize = true;
            lblLado3.Font = new Font("Segoe UI", 14.2F);
            lblLado3.Location = new Point(111, 233);
            lblLado3.Name = "lblLado3";
            lblLado3.Size = new Size(90, 32);
            lblLado3.TabIndex = 4;
            lblLado3.Text = "Lado 3:";
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(111, 314);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(312, 63);
            btnCalcular.TabIndex = 6;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(12, 12);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(122, 39);
            btnSair.TabIndex = 7;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(111, 383);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(312, 63);
            btnLimpar.TabIndex = 8;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(9F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Linen;
            ClientSize = new Size(553, 552);
            Controls.Add(btnLimpar);
            Controls.Add(btnSair);
            Controls.Add(btnCalcular);
            Controls.Add(txtLado3);
            Controls.Add(lblLado3);
            Controls.Add(txtLado2);
            Controls.Add(txtLado1);
            Controls.Add(lblLado2);
            Controls.Add(lblLado1);
            Name = "Form1";
            Text = "Isso é um triângulo...?";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblLado1;
        private Label lblLado2;
        private TextBox txtLado1;
        private TextBox txtLado2;
        private TextBox txtLado3;
        private Label lblLado3;
        private Button btnCalcular;
        private Button btnSair;
        private Button btnLimpar;
    }
}
