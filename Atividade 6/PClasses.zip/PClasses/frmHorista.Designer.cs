﻿namespace PClasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtDataEntradaEmpresa = new System.Windows.Forms.TextBox();
            this.txtNumHoras = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.btnInstMensalista = new System.Windows.Forms.Button();
            this.lblDataEntrada = new System.Windows.Forms.Label();
            this.lblSalMensal = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblMatrícula = new System.Windows.Forms.Label();
            this.txtSalHora = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtDFaltas = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtDataEntradaEmpresa
            // 
            this.txtDataEntradaEmpresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.txtDataEntradaEmpresa.Location = new System.Drawing.Point(457, 225);
            this.txtDataEntradaEmpresa.Name = "txtDataEntradaEmpresa";
            this.txtDataEntradaEmpresa.Size = new System.Drawing.Size(174, 26);
            this.txtDataEntradaEmpresa.TabIndex = 17;
            // 
            // txtNumHoras
            // 
            this.txtNumHoras.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.txtNumHoras.Location = new System.Drawing.Point(375, 184);
            this.txtNumHoras.Name = "txtNumHoras";
            this.txtNumHoras.Size = new System.Drawing.Size(256, 26);
            this.txtNumHoras.TabIndex = 16;
            // 
            // txtNome
            // 
            this.txtNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.txtNome.Location = new System.Drawing.Point(347, 94);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(284, 26);
            this.txtNome.TabIndex = 15;
            // 
            // txtMatricula
            // 
            this.txtMatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.txtMatricula.Location = new System.Drawing.Point(347, 46);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(284, 26);
            this.txtMatricula.TabIndex = 14;
            // 
            // btnInstMensalista
            // 
            this.btnInstMensalista.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
            this.btnInstMensalista.Location = new System.Drawing.Point(288, 334);
            this.btnInstMensalista.Name = "btnInstMensalista";
            this.btnInstMensalista.Size = new System.Drawing.Size(192, 67);
            this.btnInstMensalista.TabIndex = 13;
            this.btnInstMensalista.Text = "Instanciar Horista";
            this.btnInstMensalista.UseVisualStyleBackColor = true;
            this.btnInstMensalista.Click += new System.EventHandler(this.btnInstMensalista_Click);
            // 
            // lblDataEntrada
            // 
            this.lblDataEntrada.AutoSize = true;
            this.lblDataEntrada.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblDataEntrada.Location = new System.Drawing.Point(180, 225);
            this.lblDataEntrada.Name = "lblDataEntrada";
            this.lblDataEntrada.Size = new System.Drawing.Size(229, 24);
            this.lblDataEntrada.TabIndex = 12;
            this.lblDataEntrada.Text = "Data Entrada na Empresa:";
            // 
            // lblSalMensal
            // 
            this.lblSalMensal.AutoSize = true;
            this.lblSalMensal.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblSalMensal.Location = new System.Drawing.Point(180, 184);
            this.lblSalMensal.Name = "lblSalMensal";
            this.lblSalMensal.Size = new System.Drawing.Size(163, 24);
            this.lblSalMensal.TabIndex = 11;
            this.lblSalMensal.Text = "Número de horas:";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblNome.Location = new System.Drawing.Point(180, 94);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(67, 24);
            this.lblNome.TabIndex = 10;
            this.lblNome.Text = "Nome:";
            // 
            // lblMatrícula
            // 
            this.lblMatrícula.AccessibleRole = System.Windows.Forms.AccessibleRole.Clock;
            this.lblMatrícula.AutoSize = true;
            this.lblMatrícula.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblMatrícula.Location = new System.Drawing.Point(180, 46);
            this.lblMatrícula.Name = "lblMatrícula";
            this.lblMatrícula.Size = new System.Drawing.Size(90, 24);
            this.lblMatrícula.TabIndex = 9;
            this.lblMatrícula.Text = "Matrícula:";
            // 
            // txtSalHora
            // 
            this.txtSalHora.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.txtSalHora.Location = new System.Drawing.Point(347, 138);
            this.txtSalHora.Name = "txtSalHora";
            this.txtSalHora.Size = new System.Drawing.Size(284, 26);
            this.txtSalHora.TabIndex = 19;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.label1.Location = new System.Drawing.Point(180, 138);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(146, 24);
            this.label1.TabIndex = 18;
            this.label1.Text = "Salário por Hora";
            // 
            // txtDFaltas
            // 
            this.txtDFaltas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.txtDFaltas.Location = new System.Drawing.Point(457, 270);
            this.txtDFaltas.Name = "txtDFaltas";
            this.txtDFaltas.Size = new System.Drawing.Size(174, 26);
            this.txtDFaltas.TabIndex = 21;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.label2.Location = new System.Drawing.Point(180, 270);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(127, 24);
            this.label2.TabIndex = 20;
            this.label2.Text = "Dias de Faltas";
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtDFaltas);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtSalHora);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtDataEntradaEmpresa);
            this.Controls.Add(this.txtNumHoras);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.btnInstMensalista);
            this.Controls.Add(this.lblDataEntrada);
            this.Controls.Add(this.lblSalMensal);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMatrícula);
            this.Name = "frmHorista";
            this.Text = "frmHorista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtDataEntradaEmpresa;
        private System.Windows.Forms.TextBox txtNumHoras;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.Button btnInstMensalista;
        private System.Windows.Forms.Label lblDataEntrada;
        private System.Windows.Forms.Label lblSalMensal;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblMatrícula;
        private System.Windows.Forms.TextBox txtSalHora;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtDFaltas;
        private System.Windows.Forms.Label label2;
    }
}