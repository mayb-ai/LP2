﻿namespace PImc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblPeso = new Label();
            lblIMC = new Label();
            lblAltura = new Label();
            txtImc = new TextBox();
            btnCancelar = new Button();
            btnCalcular = new Button();
            btnSair = new Button();
            mskbxPeso = new MaskedTextBox();
            mskbxAltura = new MaskedTextBox();
            SuspendLayout();
            // 
            // lblPeso
            // 
            lblPeso.AutoSize = true;
            lblPeso.Font = new Font("Segoe UI", 14.2F);
            lblPeso.Location = new Point(246, 131);
            lblPeso.Margin = new Padding(4, 0, 4, 0);
            lblPeso.Name = "lblPeso";
            lblPeso.Size = new Size(134, 32);
            lblPeso.TabIndex = 0;
            lblPeso.Text = "Peso atual: ";
            // 
            // lblIMC
            // 
            lblIMC.AutoSize = true;
            lblIMC.Font = new Font("Segoe UI", 14.2F);
            lblIMC.Location = new Point(246, 247);
            lblIMC.Margin = new Padding(4, 0, 4, 0);
            lblIMC.Name = "lblIMC";
            lblIMC.Size = new Size(69, 32);
            lblIMC.TabIndex = 1;
            lblIMC.Text = "IMC: ";
            // 
            // lblAltura
            // 
            lblAltura.AutoSize = true;
            lblAltura.Font = new Font("Segoe UI", 14.2F);
            lblAltura.Location = new Point(246, 192);
            lblAltura.Margin = new Padding(4, 0, 4, 0);
            lblAltura.Name = "lblAltura";
            lblAltura.Size = new Size(89, 32);
            lblAltura.TabIndex = 2;
            lblAltura.Text = "Altura: ";
            // 
            // txtImc
            // 
            txtImc.Enabled = false;
            txtImc.Location = new Point(417, 253);
            txtImc.Margin = new Padding(4, 4, 4, 4);
            txtImc.Name = "txtImc";
            txtImc.Size = new Size(332, 35);
            txtImc.TabIndex = 5;
            // 
            // btnCancelar
            // 
            btnCancelar.Font = new Font("Segoe UI", 12.2F);
            btnCancelar.Location = new Point(246, 377);
            btnCancelar.Margin = new Padding(4, 4, 4, 4);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(163, 68);
            btnCancelar.TabIndex = 6;
            btnCancelar.Text = "Cancelar";
            btnCancelar.UseVisualStyleBackColor = true;
            btnCancelar.Click += btnCancelar_Click;
            // 
            // btnCalcular
            // 
            btnCalcular.Font = new Font("Segoe UI", 12.2F);
            btnCalcular.Location = new Point(417, 377);
            btnCalcular.Margin = new Padding(4, 4, 4, 4);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(163, 68);
            btnCalcular.TabIndex = 7;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnSair
            // 
            btnSair.Font = new Font("Segoe UI", 12.2F);
            btnSair.Location = new Point(587, 377);
            btnSair.Margin = new Padding(4, 4, 4, 4);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(163, 68);
            btnSair.TabIndex = 8;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // mskbxPeso
            // 
            mskbxPeso.Location = new Point(417, 138);
            mskbxPeso.Margin = new Padding(4, 4, 4, 4);
            mskbxPeso.Mask = "000.00";
            mskbxPeso.Name = "mskbxPeso";
            mskbxPeso.Size = new Size(332, 35);
            mskbxPeso.TabIndex = 9;
            mskbxPeso.Validated += mskbxPeso_Validated;
            // 
            // mskbxAltura
            // 
            mskbxAltura.Location = new Point(417, 198);
            mskbxAltura.Margin = new Padding(4, 4, 4, 4);
            mskbxAltura.Mask = "0.00";
            mskbxAltura.Name = "mskbxAltura";
            mskbxAltura.Size = new Size(332, 35);
            mskbxAltura.TabIndex = 10;
            mskbxAltura.Validated += mskbxAltura_Validated;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(11F, 28F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Wheat;
            ClientSize = new Size(978, 577);
            Controls.Add(mskbxAltura);
            Controls.Add(mskbxPeso);
            Controls.Add(btnSair);
            Controls.Add(btnCalcular);
            Controls.Add(btnCancelar);
            Controls.Add(txtImc);
            Controls.Add(lblAltura);
            Controls.Add(lblIMC);
            Controls.Add(lblPeso);
            Font = new Font("Segoe UI", 12.2F);
            Margin = new Padding(4, 4, 4, 4);
            Name = "Form1";
            Text = "Calculadora de IMC";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblPeso;
        private Label lblIMC;
        private Label lblAltura;
        private TextBox txtImc;
        private Button btnCancelar;
        private Button btnCalcular;
        private Button btnSair;
        private MaskedTextBox mskbxPeso;
        private MaskedTextBox mskbxAltura;
    }
}
